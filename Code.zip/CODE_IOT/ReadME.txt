WHICH CODE IN WHICH FILE?

# The whole pipeline. distance sensor reading, camera-on, count people, majority count, output people count to arduino 
face_reps_all.py

# The majority count 
face_mjcount.py

# The clustering method used for face count.
face_clusters.py

# face counts with face clustering method
face_resp.py

# the pipeline of trigger camera every 30 seconds.
run.sh

# Code for Arduino, reading temperature, humidity, people count and display on LCD screen. Control servo
arduino_ino.ino 


